#!/bin/bash

mkdir /opt/{quil5,cyberjaya,galaxy,neptune,space}

