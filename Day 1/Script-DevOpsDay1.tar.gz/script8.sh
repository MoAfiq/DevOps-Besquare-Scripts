#!/bin/bash

echo "Differences between /etc /home"
echo "/etc"
echo "~"
echo "/home"
echo "$HOME"


