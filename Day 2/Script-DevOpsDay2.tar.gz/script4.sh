#!/bin/bash

echo "Searching python in installed packages"

apt list | grep "python"
