#!/bin/bash

echo "$(whoami)"
