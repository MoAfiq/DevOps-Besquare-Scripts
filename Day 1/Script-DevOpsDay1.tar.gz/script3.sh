#!/bin/bash

touch deriv.txt

cp deriv.txt /tmp
