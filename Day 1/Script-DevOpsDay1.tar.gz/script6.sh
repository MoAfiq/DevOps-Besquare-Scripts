#!/bin/bash

echo "Write you directory"
read input

mkdir $input
