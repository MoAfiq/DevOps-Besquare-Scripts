#!/bin/bash

ls -l
