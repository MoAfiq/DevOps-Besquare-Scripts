#!/bin/bash

echo "Displaying disks partition, sorted with bigger size first"

df -h

