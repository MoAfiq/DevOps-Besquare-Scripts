#!/bin/bash

echo "Hello $(whoami)! Welcome to Deriv"
