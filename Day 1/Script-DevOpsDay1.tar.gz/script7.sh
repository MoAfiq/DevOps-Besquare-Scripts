#!/bin/bash

<<com
echo "Can you see my comment?"
echo "Cannot right?"
com
echo "You cannot see my previous comment"
