#!/bin/bash

a='BeSquare Is A Fresh Graduate Training Programme'

echo "$a" | tr '[:upper:]' '[:lower:]'
