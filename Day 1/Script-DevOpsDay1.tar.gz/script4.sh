#!/bin/bash

date

echo "$(whoami)"

pwd
